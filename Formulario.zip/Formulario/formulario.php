<?php

// Establece la conexión a la base de datos 
$servidor = "localhost";
$usuario = "root";
$contraseña = "";
$basededatos = "cultivos";

// Crea la conexión //
$conexion = new mysqli($servidor, $usuario, $contraseña, $basededatos);

// Verifica la conexion // 

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}     

// Obtiene los datos del formulario //

    $tipoCultivo = $_POST["tipo-cultivo"];
    $variedadCultivo = $_POST["variedad-cultivo"];
    $superficieCosechada = $_POST["superficie-cosechada"];
    $cultivoRotativo = $_POST["cultivo-rotativo"];
    $fechaSiembraRotativa = ($cultivoRotativo == "si") ? $_POST["fecha-siembra-rotativa"] : null;
    $fechaCosechaRotativa = ($cultivoRotativo == "si") ? $_POST["fecha-cosecha-rotativa"] : null;
    $notas = $_POST["Notas"];


// Inserta los datos en la base de datos
    $sql = "INSERT INTO Cultivos (tipo_cultivo, variedad_cultivo, superficie_cosechada, cultivo_rotativo, fecha_siembra_rotativa, fecha_cosecha_rotativa, notas) 
            VALUES ('$tipoCultivo', '$variedadCultivo', '$superficieCosechada', '$cultivoRotativo', '$fechaSiembraRotativa', '$fechaCosechaRotativa', '$notas')";

// Ejecuta la consulta
    if ($conexion->query($sql) === TRUE) {
        echo "Registro insertado correctamente";
    } else {
        echo "Error al insertar el registro: " . $conexion->error;
    }

// Cierra la conexión
    $conexion->close();

?>